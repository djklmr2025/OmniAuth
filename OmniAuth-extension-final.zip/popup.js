
/**
 * OmniAuth Offline (MV3)
 * - QR decode local using BarcodeDetector (Chrome/Edge)
 * - TOTP generated locally using WebCrypto (HMAC-SHA1)
 * - Stores secrets in chrome.storage.local
 */

const $ = (sel) => document.querySelector(sel);

const accountsEl = $("#accounts");
const emptyEl = $("#empty");
const mainEl = $("#main");
const lockOverlay = $("#lockOverlay");
const lockHint = $("#lockHint");
const vaultPass = $("#vaultPass");
const vaultPass2 = $("#vaultPass2");
const vaultConfirmWrap = $("#vaultConfirmWrap");
const btnUnlock = $("#btnUnlock");
const btnCreateVault = $("#btnCreateVault");
const btnLock = $("#btnLock");
const lockStatus = $("#lockStatus");

function setLocked(isLocked){
  if (isLocked){
    lockOverlay.classList.remove("hidden");
    mainEl.classList.add("locked");
    btnLock.classList.add("hidden");
  }else{
    lockOverlay.classList.add("hidden");
    mainEl.classList.remove("locked");
    btnLock.classList.remove("hidden");
  }
}

function setLockModeCreate(isCreate){
  if (isCreate){
    lockHint.textContent = "Crea una contraseña para proteger tus cuentas en esta bóveda local.";
    vaultConfirmWrap.classList.remove("hidden");
    btnCreateVault.classList.remove("hidden");
    btnUnlock.textContent = "🔓 Crear y desbloquear";
  }else{
    lockHint.textContent = "Desbloquea con tu contraseña para ver y administrar tus códigos.";
    vaultConfirmWrap.classList.add("hidden");
    btnCreateVault.classList.add("hidden");
    btnUnlock.textContent = "🔓 Desbloquear";
  }
}


const video = $("#video");
const canvas = $("#canvas");
const scanStatus = $("#scanStatus");
const uploadStatus = $("#uploadStatus");
const manualStatus = $("#manualStatus");

const backupPass = $("#backupPass");
const backupPass2 = $("#backupPass2");
const btnExport = $("#btnExport");
const btnImport = $("#btnImport");
const importFile = $("#importFile");
const backupStatus = $("#backupStatus");

const btnStartCam = $("#btnStartCam");
const btnStopCam = $("#btnStopCam");

const fileInput = $("#fileInput");
const issuerInput = $("#issuerInput");
const labelInput = $("#labelInput");
const secretInput = $("#secretInput");
const btnAddManual = $("#btnAddManual");
const btnClearManual = $("#btnClearManual");

let stream = null;
let scanTimer = null;
let codeTimer = null;

const STORAGE_KEY = "omniAuthAccounts";
const VAULT_KEY = "omniAuthVault";
let sessionAccounts = null;
let sessionPassword = null;
let vaultExists = false;

function setStatus(el, msg, cls="muted"){
  el.className = `status ${cls}`;
  el.textContent = msg;
}

function uuid(){
  return crypto.randomUUID ? crypto.randomUUID() : (Date.now() + "-" + Math.random().toString(16).slice(2));
}


// --------- Backup (AES-GCM + PBKDF2) ----------
const BACKUP_VERSION = 1;
const PBKDF2_ITERS = 200000; // razonable para desktop; ajustable

function bufToB64(buf){
  const bytes = new Uint8Array(buf);
  let bin = "";
  for (let i=0;i<bytes.length;i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

function b64ToBuf(b64){
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i=0;i<bin.length;i++) bytes[i] = bin.charCodeAt(i);
  return bytes.buffer;
}

async function deriveAesKey(password, saltB64, iters = PBKDF2_ITERS){
  const enc = new TextEncoder();
  const passKey = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );
  const salt = new Uint8Array(b64ToBuf(saltB64));
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt,
      iterations: iters,
      hash: "SHA-256"
    },
    passKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt","decrypt"]
  );
}

async function encryptPayload(payloadObj, password){
  const enc = new TextEncoder();
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const saltB64 = bufToB64(salt.buffer);

  const key = await deriveAesKey(password, saltB64, PBKDF2_ITERS);
  const plaintext = enc.encode(JSON.stringify(payloadObj));
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, plaintext);

  return {
    v: BACKUP_VERSION,
    kdf: { name: "PBKDF2", hash: "SHA-256", iters: PBKDF2_ITERS, salt: saltB64 },
    cipher: { name: "AES-GCM", iv: bufToB64(iv.buffer), data: bufToB64(ciphertext) }
  };
}

async function decryptPayload(backupObj, password){
  if (!backupObj || typeof backupObj !== "object") throw new Error("Archivo inválido.");
  if (backupObj.v !== BACKUP_VERSION) throw new Error("Versión de backup no soportada.");
  const kdf = backupObj.kdf || {};
  const cipher = backupObj.cipher || {};
  if (kdf.name !== "PBKDF2" || cipher.name !== "AES-GCM") throw new Error("Formato de backup inválido.");

  const key = await deriveAesKey(password, kdf.salt, kdf.iters);
  const iv = new Uint8Array(b64ToBuf(cipher.iv));
  const data = b64ToBuf(cipher.data);

  const plainBuf = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, data);
  const dec = new TextDecoder();
  const jsonText = dec.decode(plainBuf);
  return JSON.parse(jsonText);
}

function downloadText(filename, text, mime="application/octet-stream"){
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 1000);
}

// --------- Base32 decode (RFC 4648) ----------
function base32ToBytes(base32){
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const clean = (base32 || "").toUpperCase().replace(/=+$/,"").replace(/[^A-Z2-7]/g,"");
  if (!clean) throw new Error("Secret vacío o inválido.");
  let bits = 0;
  let value = 0;
  const out = [];
  for (const c of clean){
    const idx = alphabet.indexOf(c);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8){
      out.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return new Uint8Array(out);
}

// --------- Parse otpauth URI ----------
function parseOtpauth(uri){
  // Example: otpauth://totp/Issuer:Label?secret=XXXX&issuer=Issuer&digits=6&period=30
  if (!uri || typeof uri !== "string") throw new Error("URI vacío.");
  if (!uri.startsWith("otpauth://")) throw new Error("No parece un QR TOTP (otpauth://).");

  const u = new URL(uri);
  const type = (u.hostname || "").toLowerCase(); // "totp"
  if (type !== "totp") throw new Error(`Solo TOTP por ahora. Detectado: ${type || "desconocido"}`);

  const path = decodeURIComponent(u.pathname || "").replace(/^\//,""); // "Issuer:Label" or "Label"
  const params = u.searchParams;
  const secret = params.get("secret") || "";
  const issuerQ = params.get("issuer") || "";
  const digits = parseInt(params.get("digits") || "6", 10);
  const period = parseInt(params.get("period") || "30", 10);

  let issuer = issuerQ;
  let label = path;

  if (path.includes(":")){
    const [iss, lab] = path.split(":");
    issuer = issuer || iss;
    label = lab;
  }

  issuer = issuer || "Cuenta";
  label = label || "Sin etiqueta";

  return { issuer, label, secret, digits, period };
}

// --------- TOTP (RFC 6238) ----------
async function totp({secret, digits=6, period=30}, now = Date.now()){
  const keyBytes = base32ToBytes(secret);
  const counter = Math.floor(now / 1000 / period);

  // 8-byte big-endian counter
  const msg = new ArrayBuffer(8);
  const view = new DataView(msg);
  // high 32 bits
  view.setUint32(0, Math.floor(counter / 2**32));
  // low 32 bits
  view.setUint32(4, counter >>> 0);

  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "HMAC", hash: "SHA-1" },
    false,
    ["sign"]
  );

  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", cryptoKey, msg));
  const offset = sig[sig.length - 1] & 0x0f;
  const binCode =
    ((sig[offset] & 0x7f) << 24) |
    ((sig[offset + 1] & 0xff) << 16) |
    ((sig[offset + 2] & 0xff) << 8) |
    (sig[offset + 3] & 0xff);

  const otp = (binCode % (10 ** digits)).toString().padStart(digits, "0");
  const remaining = period - (Math.floor(now / 1000) % period);

  return { otp, remaining, period };
}

// --------- Storage (Vault) ----------
async function loadVault(){
  const data = await chrome.storage.local.get([VAULT_KEY]);
  return data[VAULT_KEY] && typeof data[VAULT_KEY] === "object" ? data[VAULT_KEY] : null;
}

async function saveVault(vaultObj){
  await chrome.storage.local.set({ [VAULT_KEY]: vaultObj });
}

async function clearLegacyAccounts(){
  try{ await chrome.storage.local.remove([STORAGE_KEY]); }catch(e){}
}

async function getLegacyAccounts(){
  const data = await chrome.storage.local.get([STORAGE_KEY]);
  return Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
}

function requireUnlocked(){
  if (!Array.isArray(sessionAccounts) || !sessionPassword) throw new Error("Bóveda bloqueada. Desbloquea primero.");
}

async function persistSession(){
  requireUnlocked();
  const payload = { app:"OmniAuthVault", savedAt: new Date().toISOString(), accounts: sessionAccounts };
  const vaultObj = await encryptPayload(payload, sessionPassword);
  await saveVault(vaultObj);
  vaultExists = true;
}

async function addAccount(acc){
  requireUnlocked();
  const exists = sessionAccounts.some(a => a.issuer===acc.issuer && a.label===acc.label && a.secret===acc.secret);
  if (exists) return { ok:false, msg:"Esa cuenta ya existe." };
  sessionAccounts.unshift(acc);
  await persistSession();
  return { ok:true };
}

async function removeAccount(id){
  requireUnlocked();
  sessionAccounts = sessionAccounts.filter(a => a.id !== id);
  await persistSession();
}

// --------- Render ----------
async function render(){
  requireUnlocked();
  const accounts = sessionAccounts;
  accountsEl.innerHTML = "";
  emptyEl.style.display = accounts.length ? "none" : "block";

  for (const acc of accounts){
    const el = document.createElement("div");
    el.className = "account";
    el.dataset.id = acc.id;

    el.innerHTML = `
      <div class="accTop">
        <div class="accMeta">
          <div class="accIssuer"></div>
          <div class="accLabel"></div>
        </div>
        <button class="danger btnDel" title="Eliminar">🗑️</button>
      </div>
      <div class="codeRow">
        <div class="code">------</div>
        <div class="timer">--s</div>
      </div>
    `;
    el.querySelector(".accIssuer").textContent = acc.issuer || "Cuenta";
    el.querySelector(".accLabel").textContent = acc.label || "";

    el.querySelector(".btnDel").addEventListener("click", async () => {
      await removeAccount(acc.id);
      await render();
    });

    accountsEl.appendChild(el);
  }

  // start/update codes
  if (codeTimer) clearInterval(codeTimer);
  await updateCodes();
  codeTimer = setInterval(updateCodes, 1000);
}

async function updateCodes(){
  requireUnlocked();
  const accounts = sessionAccounts;
  const now = Date.now();
  for (const acc of accounts){
    const row = accountsEl.querySelector(`.account[data-id="${acc.id}"]`);
    if (!row) continue;
    try{
      const { otp, remaining, period } = await totp(acc, now);
      row.querySelector(".code").textContent = otp.slice(0,3) + " " + otp.slice(3);
      row.querySelector(".timer").textContent = `${remaining}s / ${period}s`;
    }catch(e){
      row.querySelector(".code").textContent = "ERR";
      row.querySelector(".timer").textContent = "—";
    }
  }
}

// --------- Tabs ----------
document.querySelectorAll(".tab").forEach(btn=>{
  btn.addEventListener("click", ()=>{
    document.querySelectorAll(".tab").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    const tab = btn.dataset.tab;
    document.querySelectorAll(".tabPanel").forEach(p=>p.classList.add("hidden"));
    $("#tab-"+tab).classList.remove("hidden");
  });
});

// --------- QR decode local ----------
function barcodeDetectorSupported(){
  return ("BarcodeDetector" in window);
}

async function decodeFromImageBitmap(bitmap){
  if (!barcodeDetectorSupported()) throw new Error("BarcodeDetector no está disponible en este navegador.");
  const detector = new BarcodeDetector({ formats: ["qr_code"] });
  const codes = await detector.detect(bitmap);
  if (!codes || !codes.length) throw new Error("No se detectó un QR en la imagen.");
  return codes[0].rawValue || "";
}

async function scanFrame(){
  if (!stream) return;

  try{
    const w = video.videoWidth;
    const h = video.videoHeight;
    if (!w || !h) return;

    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(video, 0, 0, w, h);

    // Convert canvas to ImageBitmap for BarcodeDetector
    const bitmap = await createImageBitmap(canvas);
    const raw = await decodeFromImageBitmap(bitmap);

    // Found
    setStatus(scanStatus, "QR detectado. Procesando…", "ok");
    await handleOtpauth(raw);
    await stopCamera();
  }catch(e){
    // keep scanning; show muted status
    // Only show some errors, avoid spamming
    const msg = (e && e.message) ? e.message : String(e);
    if (msg.includes("BarcodeDetector")) setStatus(scanStatus, msg, "bad");
    else setStatus(scanStatus, "Buscando QR…", "muted");
  }
}

async function startCamera(){
  try{
    if (!barcodeDetectorSupported()){
      setStatus(scanStatus, "Este navegador no soporta BarcodeDetector (QR). Usa 'Subir imagen' o actualiza Chrome/Edge.", "bad");
      return;
    }

    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "environment" },
      audio: false
    });
    video.srcObject = stream;
    await video.play();

    btnStartCam.disabled = true;
    btnStopCam.disabled = false;

    setStatus(scanStatus, "Cámara encendida. Apunta al QR…", "ok");

    if (scanTimer) clearInterval(scanTimer);
    scanTimer = setInterval(scanFrame, 400);
  }catch(e){
    setStatus(scanStatus, "No se pudo abrir cámara. Revisa permisos.", "bad");
    btnStartCam.disabled = false;
    btnStopCam.disabled = true;
  }
}

async function stopCamera(){
  if (scanTimer) { clearInterval(scanTimer); scanTimer = null; }
  if (stream){
    stream.getTracks().forEach(t => t.stop());
    stream = null;
  }
  video.srcObject = null;
  btnStartCam.disabled = false;
  btnStopCam.disabled = true;
  setStatus(scanStatus, "Cámara apagada.", "muted");
}

btnStartCam.addEventListener("click", startCamera);
btnStopCam.addEventListener("click", stopCamera);

// --------- Upload image QR ----------
fileInput.addEventListener("change", async (ev)=>{
  const file = ev.target.files && ev.target.files[0];
  if (!file) return;
  try{
    if (!barcodeDetectorSupported()){
      setStatus(uploadStatus, "Este navegador no soporta BarcodeDetector (QR).", "bad");
      return;
    }

    setStatus(uploadStatus, "Analizando imagen…", "muted");

    const bmp = await createImageBitmap(file);
    const raw = await decodeFromImageBitmap(bmp);
    setStatus(uploadStatus, "QR detectado. Procesando…", "ok");
    await handleOtpauth(raw);
  }catch(e){
    setStatus(uploadStatus, (e && e.message) ? e.message : "Error leyendo imagen.", "bad");
  }finally{
    fileInput.value = "";
  }
});

// --------- Manual add ----------
btnAddManual.addEventListener("click", async ()=>{
  try{
    const issuer = issuerInput.value.trim() || "Cuenta";
    const label = labelInput.value.trim() || "Sin etiqueta";
    const secret = secretInput.value.trim().replace(/\s+/g,"");
    if (!secret) throw new Error("Secret requerido.");
    // quick validate by decoding
    base32ToBytes(secret);

    const acc = { id: uuid(), issuer, label, secret, digits: 6, period: 30 };
    const res = await addAccount(acc);
    if (!res.ok) throw new Error(res.msg);
    setStatus(manualStatus, "Cuenta agregada ✅", "ok");
  }catch(e){
    setStatus(manualStatus, (e && e.message) ? e.message : "Error.", "bad");
  }
});

btnClearManual.addEventListener("click", ()=>{
  issuerInput.value = "";
  labelInput.value = "";
  secretInput.value = "";
  setStatus(manualStatus, ".", "muted");
});

// --------- Handle otpauth ----------
async function handleOtpauth(raw){
  try{
    const data = parseOtpauth(raw.trim());
    const acc = {
      id: uuid(),
      issuer: data.issuer,
      label: data.label,
      secret: data.secret,
      digits: data.digits || 6,
      period: data.period || 30
    };
    const res = await addAccount(acc);
    if (!res.ok) throw new Error(res.msg);
    setStatus(scanStatus, `Agregada: ${acc.issuer} (${acc.label}) ✅`, "ok");
    setStatus(uploadStatus, `Agregada: ${acc.issuer} (${acc.label}) ✅`, "ok");
  }catch(e){
    const msg = (e && e.message) ? e.message : "Error procesando QR.";
    setStatus(scanStatus, msg, "bad");
    setStatus(uploadStatus, msg, "bad");
  }
}


// --------- Backup UI ----------
btnExport.addEventListener("click", async ()=>{
  try{
    const pass = (backupPass.value || "").trim();
    const pass2 = (backupPass2.value || "").trim();
    if (!pass) throw new Error("Escribe una contraseña para cifrar el respaldo.");
    if (pass.length < 8) throw new Error("Usa una contraseña de al menos 8 caracteres.");
    if (pass !== pass2) throw new Error("La confirmación no coincide.");

    requireUnlocked();
  const accounts = sessionAccounts;
    if (!accounts.length) throw new Error("No hay cuentas para respaldar.");

    const payload = {
      app: "OmniAuth",
      exportedAt: new Date().toISOString(),
      accounts
    };

    setStatus(backupStatus, "Cifrando respaldo…", "muted");
    const backupObj = await encryptPayload(payload, pass);

    const stamp = new Date().toISOString().slice(0,10).replace(/-/g,"");
    const filename = `OmniAuth-backup-${stamp}.authbackup`;
    downloadText(filename, JSON.stringify(backupObj, null, 2), "application/json");

    setStatus(backupStatus, "Respaldo exportado ✅ (archivo cifrado)", "ok");
  }catch(e){
    setStatus(backupStatus, (e && e.message) ? e.message : "Error exportando.", "bad");
  }
});

btnImport.addEventListener("click", ()=>{
  importFile.click();
});

importFile.addEventListener("change", async (ev)=>{
  const file = ev.target.files && ev.target.files[0];
  if (!file) return;
  try{
    const pass = (backupPass.value || "").trim();
    if (!pass) throw new Error("Escribe la contraseña del respaldo para importar.");

    setStatus(backupStatus, "Leyendo archivo…", "muted");
    const text = await file.text();
    let backupObj;
    try{ backupObj = JSON.parse(text); }
    catch{ throw new Error("No es JSON válido."); }

    setStatus(backupStatus, "Descifrando…", "muted");
    const payload = await decryptPayload(backupObj, pass);

    if (!payload || payload.app !== "OmniAuth") throw new Error("Este respaldo no parece de OmniAuth.");
    if (!Array.isArray(payload.accounts)) throw new Error("Respaldo sin cuentas.");

    // Basic validate structure and de-dup by issuer+label+secret
    const incoming = payload.accounts
      .filter(a => a && a.secret)
      .map(a => ({
        id: uuid(),
        issuer: a.issuer || "Cuenta",
        label: a.label || "",
        secret: String(a.secret).replace(/\s+/g,""),
        digits: Number(a.digits || 6),
        period: Number(a.period || 30)
      }));

    // Validate secrets
    for (const a of incoming) base32ToBytes(a.secret);

    requireUnlocked();
    const existing = sessionAccounts;
    const merged = [...incoming, ...existing].filter((a, idx, arr)=>{
      return idx === arr.findIndex(x => x.issuer===a.issuer && x.label===a.label && x.secret===a.secret);
    });

    sessionAccounts = merged;
    await persistSession();
    setStatus(backupStatus, `Importado ✅ (${incoming.length} cuentas, total: ${merged.length})`, "ok");
  }catch(e){
    setStatus(backupStatus, (e && e.message) ? e.message : "Error importando.", "bad");
  }finally{
    importFile.value = "";
  }
});

// --------- Vault UI ----------
btnLock.addEventListener("click", ()=>{
  sessionAccounts = null;
  sessionPassword = null;
  vaultPass.value = "";
  vaultPass2.value = "";
  setLocked(true);
  setStatus(lockStatus, "Bóveda bloqueada.", "muted");
});

btnUnlock.addEventListener("click", async ()=>{
  try{
    const pass = (vaultPass.value || "").trim();
    if (!pass) throw new Error("Escribe tu contraseña.");
    if (!vaultExists){
      // create vault
      const pass2 = (vaultPass2.value || "").trim();
      if (!pass2) throw new Error("Confirma tu contraseña.");
      if (pass !== pass2) throw new Error("Las contraseñas no coinciden.");
      setStatus(lockStatus, "Creando bóveda…", "muted");

      // migrate legacy accounts if present
      const legacy = await getLegacyAccounts();
      sessionAccounts = legacy;
      sessionPassword = pass;
      await persistSession();
      await clearLegacyAccounts();

      setLocked(false);
      setStatus(lockStatus, "Bóveda creada ✅", "ok");
      await render();
      return;
    }

    setStatus(lockStatus, "Desbloqueando…", "muted");
    const vaultObj = await loadVault();
    const payload = await decryptPayload(vaultObj, pass);
    if (!payload || !payload.accounts || !Array.isArray(payload.accounts)) throw new Error("Bóveda inválida.");
    sessionAccounts = payload.accounts;
    sessionPassword = pass;

    setLocked(false);
    setStatus(lockStatus, "Desbloqueado ✅", "ok");
    await render();
}catch(e){
    setStatus(lockStatus, (e && e.message) ? e.message : "Error desbloqueando.", "bad");
  }
});

// Init
(async function init(){
  // quick environment note
  if (!barcodeDetectorSupported()){
    setStatus(scanStatus, "BarcodeDetector no disponible. Podrás agregar manualmente.", "bad");
  }
  const v = await loadVault();
  vaultExists = !!v;
  if (vaultExists){
    setLockModeCreate(false);
    setLocked(true);
    setStatus(lockStatus, "Bóveda detectada. Desbloquea para continuar.", "muted");
  }else{
    setLockModeCreate(true);
    setLocked(true);
    setStatus(lockStatus, "No hay bóveda aún. Crea una contraseña para comenzar.", "muted");
  }
})();
